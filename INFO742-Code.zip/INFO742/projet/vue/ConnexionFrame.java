package vue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import modele.UnivBDD;

import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;

public class ConnexionFrame extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField num_Etu;
	private JTextField mdp;

	/**
	 * Create the frame.
	 */
	public ConnexionFrame() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 341, 232);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblTheGoodPlace = new JLabel("The Good Place");
		lblTheGoodPlace.setBounds(114, 11, 112, 14);
		contentPane.add(lblTheGoodPlace);
		
		JLabel lblLoginEtudiant = new JLabel("Login etudiant");
		lblLoginEtudiant.setBounds(31, 56, 101, 14);
		contentPane.add(lblLoginEtudiant);
		
		num_Etu = new JTextField();
		num_Etu.setBounds(31, 81, 101, 20);
		contentPane.add(num_Etu);
		num_Etu.setColumns(10);
		
		mdp = new JTextField();
		mdp.setColumns(10);
		mdp.setBounds(151, 81, 101, 20);
		contentPane.add(mdp);
		
		JLabel lblMotDePasse = new JLabel("Mot de passe");
		lblMotDePasse.setBounds(152, 56, 133, 14);
		contentPane.add(lblMotDePasse);
		
		JButton btnMotDePasse = new JButton("Mot de passe oubli\u00E9");
		btnMotDePasse.setBounds(152, 112, 152, 23);
		contentPane.add(btnMotDePasse);
		
		JButton btnAide = new JButton("Aide ?");
		btnAide.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnAide.setBounds(31, 112, 86, 23);
		contentPane.add(btnAide);
		
		JButton btnOk = new JButton("OK");
		btnOk.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (UnivBDD.connect(num_Etu.getText(), mdp.getText())) {
					MainFrame frame = new MainFrame();
					frame.main(null);
					ConnexionFrame.this.dispose();
				}
			}
		});
		btnOk.setBounds(99, 157, 89, 23);
		contentPane.add(btnOk);
		
	}
}