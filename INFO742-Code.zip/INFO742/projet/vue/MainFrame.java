package vue;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JSeparator;
import javax.swing.JLabel;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.JLayeredPane;
import javax.swing.JScrollPane;

import java.awt.List;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

import modele.UnivBDD;
import modele.Utilisateur;

import java.awt.Button;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class MainFrame extends JFrame{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JFrame frame;
	private JTextField textField;
	private JTable table;
	private String[] title = {"ID","Name","Description"};
	private JScrollPane scroll;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MainFrame window = new MainFrame();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public MainFrame() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 679, 518);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblTheGoodPlace = new JLabel("The Good Place");
		lblTheGoodPlace.setBounds(312, 11, 80, 14);
		frame.getContentPane().add(lblTheGoodPlace);
		
		JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);
		tabbedPane.setBounds(32, 50, 603, 386);
		frame.getContentPane().add(tabbedPane);
		
		JLayeredPane layeredPane = new JLayeredPane();
		tabbedPane.addTab("Acheter", null, layeredPane, null);
		layeredPane.setLayout(null);
		
		int NBAnnc = 0;
		for (Utilisateur s : UnivBDD.getComptes()) {
			for (int j=1; j <= s.getBdd().getAnnonces().size(); j++) {
				NBAnnc++;
			}
		}
		
		String[][] data = new String[NBAnnc][3];
		
		int i = 0;
		for (Utilisateur s : UnivBDD.getComptes()) {
			for(int j=0; j<s.getBdd().getAnnonces().size(); j++) {
				data[i][0]= s.getBdd().getAnnonces().get(j).getId();
				data[i][1]= s.getBdd().getAnnonces().get(j).getName();
				data[i][2]= s.getBdd().getAnnonces().get(j).getDescription();
				i++;
			}
		}

		DefaultTableModel model = new DefaultTableModel(data, title);
		
		table = new JTable(model);
		scroll= new JScrollPane(table);
		scroll.setBounds(15, 110, 530, 400);
		getContentPane().add(scroll);
		this.getContentPane().add(scroll);
		layeredPane.add(scroll);
		
		JLabel lblNewLabel = new JLabel("Rechercher : ");
		lblNewLabel.setBounds(27, 22, 73, 14);
		layeredPane.add(lblNewLabel);
		
		textField = new JTextField();
		textField.setBounds(97, 16, 86, 20);
		layeredPane.add(textField);
		textField.setColumns(10);
		
		Button button = new Button("Filtres");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		button.setBounds(505, 14, 70, 22);
		layeredPane.add(button);
		
		JLayeredPane layeredPane_1 = new JLayeredPane();
		tabbedPane.addTab("Vendre", null, layeredPane_1, null);
		
		JTabbedPane tabbedPane_1 = new JTabbedPane(JTabbedPane.TOP);
		tabbedPane.addTab("Information", null, tabbedPane_1, null);
		
		JSeparator separator = new JSeparator();
		separator.setBounds(32, 37, 603, 2);
		frame.getContentPane().add(separator);
	}
}
