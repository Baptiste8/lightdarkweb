package modele;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.concurrent.CopyOnWriteArrayList;

public class UnivBDD implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private static CopyOnWriteArrayList<Utilisateur> comptes;
	
	public UnivBDD(){
		setComptes(new CopyOnWriteArrayList<Utilisateur> ());
	};
	
	public CopyOnWriteArrayList<Utilisateur> getCompte(){
		return getComptes();
	}
	
	public void addCompte(Utilisateur ann){
		this.getCompte().add(ann);
	}
	
	public void deleteCompte(String num_Etu){
		for (Utilisateur s : getComptes()) {
		    if (s.getNum_Etu().equals(num_Etu)) {
		    	getComptes().remove(s);
		    }
		}
	}
	
	public Utilisateur getCompte(String num_Etu){
		for(Utilisateur ann : this.getCompte()) {
			if (ann.getNum_Etu().equals(num_Etu)){
				return ann;
			}
		}
		return null;
	}
	public void changeCompte(String num_Etu,String password, String pseudo){
		for(Utilisateur ann : this.getCompte()) {
			if (ann.getNum_Etu().equals(num_Etu)){
				ann.setPassword(password);
				ann.setPseudo(pseudo);
			}
		}
	}
	public void affiche(){
		System.out.println("Nombre comptes : " +getComptes().size());
		for (Utilisateur u: this.getCompte() ){
			System.out.println(u);
		}
	}
	
	public void sauvegarde() throws IOException{
		String userHome = System.getProperty("user.home");
		File fichier =  new File(userHome+"/Desktop/Projet_INFO742/saveUnivBDD.txt");

		 // ouverture d'un flux sur un fichier
		ObjectOutputStream oos =  new ObjectOutputStream(new FileOutputStream(fichier)) ;

		 // s�rialization de l'objet
		oos.writeObject(this) ;
	}
	
	public UnivBDD update() throws FileNotFoundException, IOException, ClassNotFoundException{


		// dans une m�thode main
		 // on simplifie le code en retirant la gestion des exceptions
		String userHome = System.getProperty("user.home");
		File fichier =  new File(userHome+"/Desktop/Projet_INFO742/saveUnivBDD.txt");

		 // ouverture d'un flux sur un fichier
		ObjectInputStream ois =  new ObjectInputStream(new FileInputStream(fichier)) ;
				
		 // d�s�rialization de l'objet
		UnivBDD m = (UnivBDD)ois.readObject() ;
		return m;

		 // fermeture du flux dans le bloc finally
	}

	public static boolean connect(String num_Etu, String password) {
		// TODO Auto-generated method stub
		boolean bool = false;
		for (Utilisateur s : getComptes()) {
		    if ((s.getNum_Etu().equals(num_Etu)) && (s.getPassword().equals(password))) {
		    	bool = true;
		    }
		}
		return bool;
	}

	public static CopyOnWriteArrayList<Utilisateur> getComptes() {
		return comptes;
	}

	public static void setComptes(CopyOnWriteArrayList<Utilisateur> comptes) {
		UnivBDD.comptes = comptes;
	}
}