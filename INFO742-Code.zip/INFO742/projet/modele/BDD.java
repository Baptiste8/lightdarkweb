package modele;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.concurrent.CopyOnWriteArrayList;

public class BDD implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private  CopyOnWriteArrayList<Annonce> annonces;
	
	public BDD(){
		annonces = new CopyOnWriteArrayList<Annonce> ();
	};
	
	public CopyOnWriteArrayList<Annonce> getAnnonces(){
		return annonces;
	}
	
	public void addAnnonce(Annonce ann){
		this.getAnnonces().add(ann);
	}
	
	public void deleteAnnonce(String idAnnonce){
		for (Annonce s : annonces) {
		    if (s.getId().equals(idAnnonce)) {
		    	annonces.remove(s);
		    }
		}
	}
	
	public void changeAnnonce(String idAnnonce,String nvname, String nvdescription, float nvprix){
		for(Annonce ann : this.getAnnonces()) {
			if (ann.getId().equals(idAnnonce)){
				ann.setName(nvname);
				ann.setDescription(nvdescription);
				ann.setPrix(nvprix);
			}
		}
	}
	
	public void sauvegarde(String bdd) throws IOException{
		String userHome = System.getProperty("user.home");
		File fichier =  new File(userHome+"/Desktop/Projet_INFO742/"+bdd+".txt");

		 // ouverture d'un flux sur un fichier
		ObjectOutputStream oos =  new ObjectOutputStream(new FileOutputStream(fichier)) ;

		 // s�rialization de l'objet
		oos.writeObject(this) ;
	}
	
	public BDD update(String bdd) throws FileNotFoundException, IOException, ClassNotFoundException{


		// dans une m�thode main
		 // on simplifie le code en retirant la gestion des exceptions
		String userHome = System.getProperty("user.home");
		File fichier =  new File(userHome+"/Desktop/Projet_INFO742/"+bdd+".txt");

		 // ouverture d'un flux sur un fichier
		ObjectInputStream ois =  new ObjectInputStream(new FileInputStream(fichier)) ;
				
		 // d�s�rialization de l'objet
		BDD m = (BDD)ois.readObject() ;
		return m;

		 // fermeture du flux dans le bloc finally
	}
}