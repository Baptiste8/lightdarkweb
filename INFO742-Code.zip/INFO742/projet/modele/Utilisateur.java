package modele;

import java.util.ArrayList;

public class Utilisateur {
	
	private String num_Etu;
	private boolean connected;
	private String password;
	private String pseudo;
	private BDD bdd;
	
	public BDD getBdd() {
		return bdd;
	}

	public void setBdd(BDD bdd) {
		this.bdd = bdd;
	}

	Utilisateur(String num_Etu){
		this.num_Etu = num_Etu;
		this.connected = false;
	}
	
	public Utilisateur(String num_Etu, String password, String pseudo,BDD bddPerso, boolean droitAdmin){
		this.num_Etu = num_Etu;
		this.connected = true;
		this.password = password;
		this.pseudo = pseudo;
		this.bdd = bddPerso;
	}
	
	public boolean isConnected() {
		return connected;
	}

	public void setConnected(boolean connected) {
		this.connected = connected;
	}

	public ArrayList<Annonce> recherche(String Filtre){
		ArrayList<Annonce> res = new ArrayList<Annonce>();
		for(Annonce ann : bdd.getAnnonces()) {
			if(ann.getName().contains(Filtre) && ann.getDescription().contains(Filtre)){
				res.add(ann);
			}
		}
		return res;
	}
	
	public void identification(String num_Etu, String password, String pseudo){
		new Utilisateur(num_Etu,password,pseudo,bdd,false);
	}
	
	public void acheter(String idAnnonce){
		APIBank.ProcedureBanq();
	}
	
	public void supprimerAnnonce(String idAnnonce){
		bdd.deleteAnnonce(idAnnonce);
	}
	
	public void modifierAnnonce(String idAnnonce,String nvname, String nvdescription, float nvprix){
		bdd.changeAnnonce(idAnnonce, nvname, nvdescription, nvprix);
	}
	
	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	@Override
	public String toString() {
		return "Utilisateur [num_Etu=" + num_Etu + ", connected=" + connected
				+ ", password=" + password + ", pseudo=" + pseudo + ", bdd="
				+ bdd + "]";
	}

	public String getPseudo() {
		return pseudo;
	}

	public void setPseudo(String pseudo) {
		this.pseudo = pseudo;
	}

	public void setNum_Etu(String num_Etu) {
		this.num_Etu = num_Etu;
	}

	public String getNum_Etu(){
		return this.num_Etu;
	}
}
