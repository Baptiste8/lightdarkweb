package modele;
import java.io.*;
import java.text.SimpleDateFormat;
import java.util.Date;
// La classe est finale, car un singleton n'est pas cens� avoir d'h�ritier.
public final class Historique {

	// L'utilisation du mot cl� volatile, en Java version 5 et sup�rieure,
	// permet d'�viter le cas o� "Singleton.instance" est non nul,
	// mais pas encore "r�ellement" instanci�.
	private static volatile Historique instance = null;

	// D'autres attributs, classiques et non "static".TODO
	final String chemin="E:/test.txt";

	/**
	 * Constructeur de l'objet.
	 */
	private Historique() {
		// La pr�sence d'un constructeur priv� supprime le constructeur public par d�faut.
		// De plus, seul le singleton peut s'instancier lui-m�me.
		super();
	}

	/**
	 * M�thode permettant de renvoyer une instance de la classe Singleton
	 * @return Retourne l'instance du singleton.
	 */
	public final static Historique getInstance() {
		//Le "Double-Checked Singleton"/"Singleton doublement v�rifi�" permet 
		//d'�viter un appel co�teux � synchronized, 
		//une fois que l'instanciation est faite.
		if (Historique.instance == null) {
			// Le mot-cl� synchronized sur ce bloc emp�che toute instanciation
			// multiple m�me par diff�rents "threads".
			// Il est TRES important.
			synchronized(Historique.class) {
				if (Historique.instance == null) {
					Historique.instance = new Historique();
				}
			}
		}
		return Historique.instance;
	}

	public void warning() {
		//TODO

	}

	public void connexion(String utilisateur) {
		Date maDate = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yy");
		SimpleDateFormat sdh = new SimpleDateFormat("hh:mm");
		String content = "L'utilisateur "+utilisateur+" s'est connect� au serveur le "+sdf.format(maDate)+" � "+sdh.format(maDate);
		try(FileWriter fw = new FileWriter(chemin, true);
				BufferedWriter bw = new BufferedWriter(fw);
				PrintWriter out = new PrintWriter(bw))
				{
			out.println(content);
				}
		catch (IOException e)
		{
			//Gestion des exceptions en cas de probl�me d'acc�s au fichier
		}
	}}
