package modele;

/*La classe Service est une classe fille de la classe Annonce.
 * Elle permet de mettre en �vidence le fonctionnement du 
 * patron Strat�gie.*/

public class Service extends Annonce{
	
	private String duree;

	public Service(String id,String name,String description, float prix, String duree){
		super(id, name, description, prix);
		this.duree = duree;
	}

	public String getDuree() {
		return duree;
	}

	public void setDuree(String duree) {
		this.duree = duree;
	}
}
