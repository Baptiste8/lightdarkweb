package modele;

/*Classe permettant de simuler un proc�dure d'achat*/

public class APIBank {

	public static void ProcedureBanq() {
		// TODO Auto-generated method stub
		
	}

}
