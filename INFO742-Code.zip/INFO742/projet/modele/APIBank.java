package modele;

public class APIBank {

	public static void ProcedureBanq() {
		// TODO Auto-generated method stub
		
	}

}
