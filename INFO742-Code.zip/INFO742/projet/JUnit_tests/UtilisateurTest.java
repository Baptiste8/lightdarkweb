package JUnit_tests;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import modele.BDD;
import modele.Logement;
import modele.UnivBDD;
import modele.Utilisateur;

public class UtilisateurTest {
	
	protected Utilisateur utilisateur;
	protected Logement logement;
	protected UnivBDD univbdd;
	protected int univtaillebdd;
	protected BDD bdd;
	protected int taillebdd;

	@Before
	//M�thode pour initialiser les classes pour le test
	public void setUp() throws Exception {
		logement = new Logement("0001","ann","des",1.0f);
		bdd = new BDD();
		univbdd = new UnivBDD();
		univbdd.addCompte(new Utilisateur("1234","mdp","Pseudo",true));
		utilisateur = new Utilisateur("1234","mdp","Pseudo",false);
		bdd.addAnnonce(utilisateur,logement);
		bdd.sauvegarde();
	}
	
	@Test
	//Test prouvant que l'on peut ajouter des utilisateurs correctement
	public void testAjoutUtilisateur() throws Exception{
		taillebdd = univbdd.getComptes().size();
		univbdd.addCompte(utilisateur);
		assertEquals(univbdd.getComptes().size(),
				taillebdd+1);
	}
	
	@Test
	//Test prouvant que l'on peut supprimer un utilisateur correctement
	public void testDeleteUtilisateur() throws Exception{
		taillebdd = univbdd.getComptes().size();
		univbdd.deleteCompte(utilisateur.getNum_Etu());
		assertEquals(univbdd.getComptes().size(),
				taillebdd-1);
	}
	
	@Test
	//Test prouvant qu'on peut modifier un utilisateur
	public void testModifyUtilisateur() throws Exception{
		univbdd.changeCompte(utilisateur.getNum_Etu(), "nvmdp", "nvpseudo");
		Utilisateur u = univbdd.getCompte(utilisateur.getNum_Etu());
		assertEquals(new String("1234"),
				u.getNum_Etu());
		assertEquals(new String("nvmdp"),
				u.getPassword());
		assertEquals(new String("nvpseudo"),
				u.getPseudo());
	}
	
	@Test
	//Test prouvant qu'on peut sauvegarder et charger un utilisateur
	public void testSaveUtilisateur() throws Exception{
		univbdd.sauvegarde();
		univbdd.deleteCompte(utilisateur.getNum_Etu());
		univbdd.update();
		assertEquals(new String("1234"),
				utilisateur.getNum_Etu());
	}
}
