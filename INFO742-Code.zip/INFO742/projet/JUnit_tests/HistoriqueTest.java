package JUnit_tests;

import static org.junit.Assert.*;

import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.junit.Before;
import org.junit.Test;

import modele.BDD;
import modele.Logement;
import modele.UnivBDD;
import modele.Utilisateur;

public class HistoriqueTest {
	protected Utilisateur utilisateur;
	protected Logement logement;
	protected UnivBDD univbdd;
	protected int univtaillebdd;
	protected BDD bdd;
	protected int taillebdd;

	@Before
	//M�thode pour initialiser les classes pour le test
	public void setUp() throws Exception {
		logement = new Logement("0001","ann","des",1.0f);
		bdd = new BDD();
		univbdd = new UnivBDD();
		univbdd.addCompte(new Utilisateur("1234","mdp","Pseudo",true));
		utilisateur = new Utilisateur("1234","mdp","Pseudo",false);
		bdd.addAnnonce(utilisateur,logement);
		bdd.sauvegarde();
	}
	
	@Test
	//Test permettant de mettre en �vidence le fonctionnement de la classe historique
	public void testHistorique() throws Exception{
		Date maDate = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yy");
		SimpleDateFormat sdh = new SimpleDateFormat("hh:mm");
		UnivBDD.connect(utilisateur.getNum_Etu(), utilisateur.getPassword());
		String message = "L'utilisateur "+utilisateur.getNum_Etu()+" s'est connect� au serveur le "+sdf.format(maDate)+" � "+sdh.format(maDate);
		
		String userHome = System.getProperty("user.home");
		String chemin = userHome+"/Desktop/Projet_INFO742/Historique.txt";
		FileReader fr=new FileReader(chemin);    
        int i;
        String s = "";
        while((i=fr.read())!=-1) {
        	s=s+(char)i;
        }
        fr.close();
		
		assertEquals(new String(message)+"\n",
				s.subSequence(s.length()-(message.length()+2), s.length()));
	}
}
