package JUnit_tests;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import modele.BDD;
import modele.Logement;
import modele.UnivBDD;
import modele.Utilisateur;

public class AnnonceTest {
	protected Utilisateur utilisateur;
	protected Logement logement;
	protected UnivBDD univbdd;
	protected int univtaillebdd;
	protected BDD bdd;
	protected int taillebdd;

	@Before
	//M�thode pour initialiser les classes pour le test
	public void setUp() throws Exception {
		logement = new Logement("0001","ann","des",1.0f);
		bdd = new BDD();
		univbdd = new UnivBDD();
		univbdd.addCompte(new Utilisateur("1234","mdp","Pseudo",true));
		utilisateur = new Utilisateur("1234","mdp","Pseudo",false);
		bdd.addAnnonce(utilisateur,logement);
		bdd.sauvegarde();
	}
	
	@Test
	//Test prouvant que l'on peut ajouter des annonces correctement
	public void testAjoutAnnonce() throws Exception{
		taillebdd = bdd.getAnnonces().size();
		bdd.addAnnonce(utilisateur,logement);
		assertEquals(bdd.getAnnonces().size(),
				taillebdd+1);
	}
	
	@Test
	//Test prouvant que l'on peut supprimer une annonce correctement
	public void testDeleteAnnonce() throws Exception{
		taillebdd = bdd.getAnnonces().size();
		bdd.deleteAnnonce(utilisateur,logement.getId());
		assertEquals(bdd.getAnnonces().size(),
				taillebdd-1);
	}
	
	@Test
	//Test prouvant qu'on peut modifier une annonce
	public void testModifyAnnonce() throws Exception{
		bdd.changeAnnonce(utilisateur,"0001", "ann2", "des2", 2.0f);
		assertEquals(new String("0001"),
				logement.getId());
		assertEquals(new String("ann2"),
				logement.getName());
		assertEquals(new String("des2"),
				logement.getDescription());
	}
	
	@Test
	//Test prouvant qu'on peut sauvegarder et charger une annonce
	public void testSaveAnnonce() throws Exception{
		bdd.sauvegarde();
		bdd.deleteAnnonce(utilisateur, logement.getId());
		bdd.update();
		assertEquals(new String("0001"),
				logement.getId());
	}
}
