package classesObservation;

public interface Observateur {
	public void notifier();
}
